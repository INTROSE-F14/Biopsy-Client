/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package autocomplete;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Lars Navarro
 */
public class dictionary {
    public void addWord(String word){
       Connection con;
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost/test?" +
                                   "user=root&password=Fac3book!");
            Statement stmt = null;
            String query = "select * from dictionary.words where word like '" + word + "%' ORDER BY word asc";

            try {
                stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(query);
                if(!rs.next()){
                    stmt.executeUpdate("INSERT INTO `dictionary`.`words` (`word`) VALUES ('"+word+"');");
                    System.out.println(word+" is not in database. Added to database.");
                }
                else{
                    System.out.println(word+" is already in dictionary.");
                }
            } catch (SQLException e) {
                System.out.println("error");
            } finally {
                if (stmt != null) {
                    stmt.close();
                }
            }
        } catch (SQLException ex) {
            // handle any errors
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
    }
    public void getSuggested(String word) {
        Connection con;
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost/test?" +
                                   "user=root&password=Fac3book!");
            Statement stmt = null;
            String query = "select * from dictionary.words where word like '" + word + "%' ORDER BY word asc";

            try {
                stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(query);
                while(rs.next()){
                    String data = rs.getString("word");
                    System.out.println(data);
                }
            } catch (SQLException e) {
                System.out.println("error");
            } finally {
                if (stmt != null) {
                    stmt.close();
                }
            }
        } catch (SQLException ex) {
            // handle any errors
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
    }
}
