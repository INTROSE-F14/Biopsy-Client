/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package autocomplete;

import java.awt.BorderLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;
/**
 *
 * @author Lars Navarro
 */
public class AutoComplete {
    KeyEvent event;
    private int JFrame;
    public AutoComplete() throws IOException {
        String word = "b";
        dictionary dictionary = new dictionary();
        dictionary.getSuggested(word); // prints in console all words with "bo" as beginning
        dictionary.addWord("soccer"); // adds a word IF not yet existing
    }
}

