/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package autocomplete;

import java.awt.event.KeyEvent;
import java.io.IOException;

/**
 *
 * @author Lars Navarro
 */
public class Driver {
    public static void main(String[] args) throws IOException{
        AutoComplete a = new AutoComplete();
    }
}
